# Gacha Game Design Guidelines: Umamusume-Style Application

## Design Approach
**Reference-Based**: Drawing from successful gacha games (Genshin Impact, Arknights, Uma Musume Pretty Derby) with anime-aesthetic card designs, gradient overlays, and premium gaming UI patterns.

## Layout System
**Spacing**: Tailwind units of 2, 4, 6, and 8 for consistency (p-4, gap-6, etc.)
**Mobile-First**: Design assumes 375px-428px primary viewport, scaling up to tablet

## Typography Hierarchy
- **Primary Font**: "Outfit" (Google Fonts) - headings, UI elements
- **Secondary Font**: "Inter" (Google Fonts) - body text, descriptions
- **Hierarchy**:
  - Hero/Page Titles: text-4xl font-bold (Outfit)
  - Section Headers: text-2xl font-semibold (Outfit)
  - Card Titles: text-lg font-bold (Outfit)
  - Stats/Labels: text-sm font-medium uppercase tracking-wide
  - Body: text-base (Inter)

## Core Layout Structure

### Sidebar Navigation (Left, Fixed)
- Width: 280px desktop, full-overlay on mobile
- Sticky position with z-50 layering
- Navigation items with icon (Heroicons) + label
- Active state: gradient border-l-4 accent
- User profile card at top: avatar, username, level badge

### Main Content Area
- Padding: px-6 py-4 mobile, px-8 py-6 desktop
- Max-width constraint: none (full bleed cards)

## Component Specifications

### Character Cards (Primary UI Element)
**Card Container**:
- Aspect ratio: 3:4 portrait orientation
- Rounded corners: rounded-2xl
- Layered structure: character image base + gradient overlay + info panel
- Drop shadow: shadow-2xl for depth
- Border: 2px solid with rarity-based treatment

**Card Content Layers**:
1. Full-bleed character illustration (background)
2. Bottom gradient overlay (top-transparent to opaque)
3. Info panel (absolute bottom): Character name, star rating (★★★★☆), level indicator, type badges
4. Top-right corner: Rarity frame icon/badge

**Grid Layout**:
- Mobile: grid-cols-2 gap-4
- Tablet: grid-cols-3 gap-6
- Desktop: grid-cols-4 gap-6

### Buttons
**Primary CTA** (Gacha Pull):
- Large pill shape: rounded-full px-8 py-4
- Glass morphism effect when on images: backdrop-blur-md bg-white/20
- Icon + Text combination
- Scale interaction ready

**Secondary Actions**:
- rounded-lg px-6 py-3
- Outlined style with 2px borders
- Icon optional

**Icon Buttons**:
- Square: w-12 h-12, rounded-lg
- Centered icon (24px Heroicons)

### Resource Display Bar
Fixed top bar showing:
- Premium currency (gems) with icon
- Soft currency (coins) with icon
- Energy/stamina with progress indicator
- All inline-flex with gap-4, text-sm font-semibold

### Home Page Structure
1. **Hero Banner** (Full-width):
   - Height: min-h-[400px] mobile, min-h-[500px] desktop
   - Featured character illustration backdrop
   - Gradient overlay bottom-up
   - Centered content: Event title (text-5xl), countdown timer, "Pull Now" CTA with backdrop-blur

2. **Featured Characters Section**:
   - Grid of 6 character cards
   - Section header with "New Arrivals" + "View All" link

3. **Daily Missions Panel**:
   - Card list (rounded-xl, p-4 each)
   - Checkbox + mission text + reward icons
   - Progress bars for collection tasks

4. **News/Events Carousel**:
   - Horizontal scroll snap cards
   - Each card: thumbnail + title + date

### Inventory Page Structure
1. **Filter Bar**:
   - Horizontal pills for rarity filters
   - Sort dropdown (Level, Rarity, Name)
   - Search input with icon

2. **Character Grid**:
   - Same card pattern as Home
   - Pagination or infinite scroll
   - Empty state: centered illustration + "No characters yet"

## Visual Accents
- **Shine Effects**: Diagonal gradient overlays on rare cards
- **Badge System**: Circular badges for NEW, MAX LEVEL, FAVORITE
- **Dividers**: 1px gradient lines between sections
- **Corner Ornaments**: Small decorative frames on premium cards

## Images Required

### Hero Section (Home Page)
**Large Hero Image**: Full-width featured character illustration
- Dimensions: 1920x1080 landscape, cropped to viewport
- Style: Dynamic pose, vibrant background, professional anime illustration
- Placement: Behind hero content with gradient overlay (transparent top, dark bottom)
- Treatment: Slight blur filter (blur-sm) for text legibility

### Character Cards (Throughout)
**Individual Character Portraits**: ~30-50 unique illustrations
- Dimensions: 600x800 portrait aspect ratio
- Style: Consistent anime art style, dynamic poses, individual personalities
- Placement: Full-bleed card backgrounds
- Treatment: Sharp, no filters on main image

### UI Icons
Use **Heroicons** (Outline) for navigation, actions, and UI elements

## Mobile Optimization
- Touch targets: minimum 44px height
- Swipe gestures for card details
- Hamburger menu triggers sidebar overlay
- Bottom navigation bar alternative for primary tabs
- Safe area insets respected (notch/home indicator)

## Performance Notes
- Lazy load character images below fold
- Optimize hero image with WebP format
- Virtual scrolling for large inventories
- Skeleton screens during loads

This creates a premium gacha game experience with rich visual hierarchy, clear navigation, and engaging character presentation optimized for mobile-first gameplay.