import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export * from "./models/auth";
import { users } from "./models/auth";

// === TABLE DEFINITIONS ===

export const characters = pgTable("characters", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  rarity: integer("rarity").notNull(), // 1, 2, 3
  imageUrl: text("image_url").notNull(),
  description: text("description"),
});

export const wallets = pgTable("wallets", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id),
  carrots: integer("carrots").notNull().default(15000), // Start with plenty for fun
  coins: integer("coins").notNull().default(0), // Coins from duplicates
  lastDailyReward: timestamp("last_daily_reward"),
});

export const userCharacters = pgTable("user_characters", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id),
  characterId: integer("character_id").notNull().references(() => characters.id),
  obtainedAt: timestamp("obtained_at").defaultNow(),
});

// === RELATIONS ===
export const userCharactersRelations = relations(userCharacters, ({ one }) => ({
  user: one(users, {
    fields: [userCharacters.userId],
    references: [users.id],
  }),
  character: one(characters, {
    fields: [userCharacters.characterId],
    references: [characters.id],
  }),
}));

export const walletsRelations = relations(wallets, ({ one }) => ({
  user: one(users, {
    fields: [wallets.userId],
    references: [users.id],
  }),
}));

// === BASE SCHEMAS ===
export const insertCharacterSchema = createInsertSchema(characters).omit({ id: true });
export const insertWalletSchema = createInsertSchema(wallets).omit({ id: true });
export const insertUserCharacterSchema = createInsertSchema(userCharacters).omit({ id: true, obtainedAt: true });

// === EXPLICIT API CONTRACT TYPES ===
export type Character = typeof characters.$inferSelect;
export type Wallet = typeof wallets.$inferSelect;
export type UserCharacter = typeof userCharacters.$inferSelect;

export type User = typeof users.$inferSelect;

export type PullRequest = {
  amount: 1 | 10;
};

export type PullResponse = {
  results: Character[];
  newBalance: number;
};

export type WalletResponse = {
  carrots: number;
};

export type InventoryItem = Character & { obtainedAt: string | null; count: number };
