## Packages
framer-motion | Essential for gacha pull animations and reveal effects
lucide-react | Icons for UI elements (already in stack but good to confirm usage)
clsx | Utility for conditional class names
tailwind-merge | Utility for merging tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
