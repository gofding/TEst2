import { useAuth } from "@/hooks/use-auth";
import { usePullGacha, useWallet } from "@/hooks/use-gacha";
import { Button } from "@/components/ui/button";
import { GachaReveal } from "@/components/GachaReveal";
import { Carrot, Sparkles, AlertCircle } from "lucide-react";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { motion, AnimatePresence } from "framer-motion";
import { useButtonSound } from "@/hooks/useButtonSound.ts";


const BANNERS = [
  {
    title: "Agnes Tachyon (Alt)",
    subtitle: "The Science of Victory",
    image: "https://pbs.twimg.com/media/GNGv0ZRbkAAF-yf?format=jpg&name=medium",
    tag: "Limited Rate Up!"
  },
  {
    title: "Manhattan Cafe (Valentine)",
    subtitle: "A Sweet Dark Roast",
    image: "https://www.4gamer.net/games/414/G041434/20240130018/SS/001.jpg",
    tag: "Valentine Special"
  },
  {
    title: "Gold Ship (Summer)",
    subtitle: "The Great Ocean Adventure",
    image: "https://pbs.twimg.com/media/FYuMkMIVUAAYnk6?format=jpg&name=medium",
    tag: "Summer Festival"
  },
  {
    title: "Special Week (New Year)",
    subtitle: "First Sunrise of the Year",
    image: "https://app.famitsu.com/wp-content/uploads/2022/07/IMG_0307-horz-506x320.jpg",
    tag: "New Year Celebration"
  },
  {
    title: "Oguri Cap (Christmas)",
    subtitle: "The Holy Night's Feast",
    image: "https://www.siliconera.com/wp-content/uploads/2026/01/g97pfbsbcayu2zl.jpg?fit=710%2C400",
    tag: "Winter Wishes"
  }
];

export default function Home() {
  const { user, isLoading: authLoading } = useAuth();
  const { data: wallet } = useWallet();
  const { mutateAsync: pullGacha, isPending: isPulling } = usePullGacha();
  const { toast } = useToast();

  const playClick = useButtonSound(
    "https://raw.githubusercontent.com/gofding/TEst2/main/umamusume_gate_enter.mp3"
  );

  const [revealResults, setRevealResults] = useState<any[]>([]);
  const [isRevealOpen, setIsRevealOpen] = useState(false);
  const [isSummonLoading, setIsSummonLoading] = useState(false);
  const [isPlayingGachaMusic, setIsPlayingGachaMusic] = useState(false);
  const [currentBannerIdx, setCurrentBannerIdx] = useState(0);

  // Rotate banners automatically
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentBannerIdx(prev => (prev + 1) % BANNERS.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const handlePull = async (amount: 1 | 10) => {
    if (!wallet) return;

    const cost = amount === 1 ? 150 : 1500;
    if (wallet.carrots < cost) {
      toast({
        title: "Insufficient Carrots",
        description: "You need more carrots to summon!",
        variant: "destructive"
      });
      return;
    }
    
    try {
      setIsSummonLoading(true);
      setIsPlayingGachaMusic(true);
      await new Promise(resolve => setTimeout(resolve, 3000));
      const data = await pullGacha(amount);
      setRevealResults(data.results);
      setIsRevealOpen(true);
    } catch (error: any) {
      toast({
        title: "Summon Failed",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setIsSummonLoading(false);
    }
  };

  if (authLoading) return null;

  if (!user) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center text-center p-8 relative">
        {/* Background music */}
        <iframe
          width="0"
          height="0"
          src="https://www.youtube.com/embed/FCj0FsgzVS4?autoplay=1&loop=1&playlist=FCj0FsgzVS4"
          title="Title Theme"
          frameBorder="0"
          allow="autoplay; encrypted-media"
          className="hidden"
        ></iframe>

        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="max-w-2xl mx-auto space-y-8"
        >
          <h1 className="text-5xl md:text-7xl font-display font-black text-primary drop-shadow-sm tracking-tight">
            Derby <span className="text-secondary">Gacha</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-lg mx-auto leading-relaxed">
            Collect your favorite horse girls in this fan-made simulator.
            Join the race today!
          </p>
          <Button
            size="lg"
            className="text-lg px-12 py-8 rounded-full shadow-xl shadow-primary/30 hover:scale-105 transition-all"
            onClick={() => {
              playClick(); // 🔊 plays your click sound
              window.location.href = "/api/login";
            }}
          >
            Start Summoning
          </Button>

          <div className="mt-12 rounded-3xl overflow-hidden shadow-2xl border-4 border-white rotate-2 hover:rotate-0 transition-transform duration-500">
            <img
              src="https://cdn-media.sforum.vn/storage/app/media/Bookgrinder2/umamusume-8.jpg"
              alt="Race track"
              className="w-full h-64 object-cover"
            />
          </div>
        </motion.div>
      </div>
    );
  }

  const currentBanner = BANNERS[currentBannerIdx];

  return (
    <>
      {/* ✅ Gacha Music (stays on until Back / Scout More) */}
      {isPlayingGachaMusic && (
        <iframe
          width="0"
          height="0"
          src="https://www.youtube.com/embed/A-podc_azuI?autoplay=1&loop=1&playlist=A-podc_azuI"
          title="Gacha Music"
          frameBorder="0"
          allow="autoplay; encrypted-media"
          className="hidden"
        ></iframe>
      )}

      {/* Loading overlay */}
      <AnimatePresence>
        {isSummonLoading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-white/95 backdrop-blur-sm"
          >
            {/* 🔸 removed the iframe from here */}
            <div className="relative w-32 h-32 mb-8">
              <div className="absolute inset-0 border-4 border-primary/20 rounded-full" />
              <div className="absolute inset-0 border-4 border-primary rounded-full border-t-transparent animate-spin" />
              <div className="absolute inset-0 flex items-center justify-center">
                <Carrot className="w-12 h-12 text-primary animate-bounce" />
              </div>
            </div>
            <h2 className="text-2xl font-black text-primary animate-pulse uppercase tracking-widest">
              Preparing for Race...
            </h2>
            <p className="text-muted-foreground font-bold mt-2">
              Gathering horse girls to the track
            </p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Reveal Results */}
      <GachaReveal
        results={revealResults}
        isOpen={isRevealOpen}
        onClose={() => {
          setIsRevealOpen(false);
          setIsPlayingGachaMusic(false); // stops when Back is pressed
        }}
        onRedo={() => {
          setIsRevealOpen(false);
          setIsPlayingGachaMusic(false); // stop briefly before re-pull
          setTimeout(() => handlePull(revealResults.length as 1 | 10), 100);
        }}
        
      />

      <div className="max-w-5xl mx-auto space-y-12 py-8 px-4 relative">
        {/* Background music when not playing gacha */}
        {!isPlayingGachaMusic && (
          <iframe
            width="0"
            height="0"
            src="https://www.youtube.com/embed/gZbOFCgDuQ4?autoplay=1&loop=1&playlist=gZbOFCgDuQ4"
            title="Background Music"
            frameBorder="0"
            allow="autoplay; encrypted-media"
            className="hidden"
          ></iframe>
        )}

        {/* Hero Banner */}
        <section className="relative rounded-3xl overflow-hidden shadow-2xl bg-gradient-to-br from-gray-900 to-gray-800 text-white aspect-[21/9] min-h-[400px] flex items-center justify-center group">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentBannerIdx}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1 }}
              className="absolute inset-0"
            >
              <img
                src={currentBanner.image}
                alt={currentBanner.title}
                className="w-full h-full object-cover opacity-60"
              />
            </motion.div>
          </AnimatePresence>

          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />

          <div className="relative z-10 text-center space-y-4 p-8">
            <motion.div
              key={`tag-${currentBannerIdx}`}
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              className="inline-block px-4 py-1 bg-yellow-400 text-black font-bold rounded-full text-sm mb-2"
            >
              {currentBanner.tag}
            </motion.div>
            <motion.h2
              key={`title-${currentBannerIdx}`}
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.1 }}
              className="text-4xl md:text-6xl font-display font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-white to-yellow-200 drop-shadow-sm"
            >
              {currentBanner.title}
            </motion.h2>
            <p className="text-lg md:text-xl text-gray-200 font-medium max-w-lg mx-auto">
              {currentBanner.subtitle}. Increased rates for 4★ characters!
            </p>
          </div>
        </section>

        {/* Summon Buttons */}
        <section className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-8 max-w-3xl mx-auto px-2">
          {/* Single Pull */}
          <Button
            onClick={() => {
              playClick(); // 🔊 plays click sound
              handlePull(1);
            }}
            disabled={isPulling}
            className="relative h-auto py-4 sm:py-6 flex flex-col items-center gap-2
              bg-white hover:bg-gray-50 text-gray-800 border-2 border-border
              rounded-2xl shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all"
          >
            <span className="text-lg sm:text-xl font-display font-bold">
              Single Pull
            </span>
            <div className="flex items-center gap-1.5 text-orange-600 bg-orange-50 px-3 py-1 rounded-full text-sm font-bold">
              <Carrot className="w-4 h-4 fill-current" />
              150
            </div>
          </Button>

          {/* 10x Summon */}
          <Button
            onClick={() => {
              playClick(); // 🔊 plays click sound
              handlePull(10);
            }}
            disabled={isPulling}
            className="relative h-auto py-4 sm:py-6 flex flex-col items-center gap-2
              bg-gradient-to-br from-primary to-primary/80 text-white border-none
              rounded-2xl shadow-lg shadow-primary/30 hover:shadow-xl hover:shadow-primary/40 hover:-translate-y-1 transition-all"
          >
            <div className="absolute -top-3 -right-3 bg-yellow-400 text-yellow-900 text-xs font-bold px-3 py-1 rounded-full shadow-md animate-bounce">
              SR Guaranteed!
            </div>
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-yellow-200" />
              <span className="text-lg sm:text-xl font-display font-bold">
                10x Summon
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-white bg-white/20 px-3 py-1 rounded-full text-sm font-bold">
              <Carrot className="w-4 h-4 fill-orange-400 text-orange-400" />
              1,500
            </div>
          </Button>
        </section>

        {/* Info Footer */}
        <section className="text-center text-sm text-muted-foreground pb-12">
          <p className="flex items-center justify-center gap-2">
            <AlertCircle className="w-4 h-4" />
            <span>Drop Rates: 4★ (0.1%), 3★ (0.6%), 2★ (18%), 1★ (81.3%)</span>
          </p>
        </section>
      </div>
    </>
  );
}
