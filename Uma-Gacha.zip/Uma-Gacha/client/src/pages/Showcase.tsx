import { useQuery } from "@tanstack/react-query";
import { Character } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { CharacterCard } from "@/components/CharacterCard";

export default function Showcase() {
  const { data: characters, isLoading } = useQuery<Character[]>({
    queryKey: ["/api/characters"],
  });

  if (isLoading) {
    return (
      <div className="p-6 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
        {[...Array(10)].map((_, i) => (
          <div key={i} className="aspect-[2/3] w-full">
            <Skeleton className="h-full w-full rounded-2xl" />
          </div>
        ))}
      </div>
    );
  }

  const sortedCharacters = [...(characters || [])].sort((a, b) => b.rarity - a.rarity);

  return (
    <div className="p-6 space-y-8">
      <div className="flex flex-col gap-1">
        <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Character Showcase</h1>
        <p className="text-muted-foreground text-lg">Browse all available Uma Musume characters in the game.</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6 lg:gap-8">
        {sortedCharacters.map((char) => (
          <div key={char.id} className="w-full">
            <CharacterCard character={char} />
          </div>
        ))}
      </div>
    </div>
  );
}
