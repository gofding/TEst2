import { useInventory } from "@/hooks/use-gacha";
import { Layout } from "@/components/Layout";
import { CharacterCard } from "@/components/CharacterCard";
import { useState } from "react";
import { Search, Filter, Coins, RefreshCw } from "lucide-react";
import { useWallet } from "@/hooks/use-gacha";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";

export default function Inventory() {
  const { data: inventory, isLoading } = useInventory();
  const { data: wallet } = useWallet();
  const { toast } = useToast();
  const [filterRarity, setFilterRarity] = useState<number | null>(null);
  const [search, setSearch] = useState("");
  const [isTrading, setIsTrading] = useState(false);

  const handleTrade = async () => {
    if (!wallet || wallet.coins < 100) {
      toast({
        title: "Not enough coins",
        description: "You need at least 100 coins to trade for carrots.",
        variant: "destructive"
      });
      return;
    }

    setIsTrading(true);
    try {
      await apiRequest("POST", "/api/user/trade-coins", { amount: 100 });
      toast({
        title: "Trade Successful!",
        description: "Exchanged 100 coins for 1,000 carrots!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/user/wallet"] });
    } catch (e) {
      toast({
        title: "Error",
        description: "Failed to trade coins.",
        variant: "destructive"
      });
    } finally {
      setIsTrading(false);
    }
  };

  const filteredInventory = inventory?.filter(item => {
    const matchesRarity = filterRarity ? item.rarity === filterRarity : true;
    const matchesSearch = item.name.toLowerCase().includes(search.toLowerCase());
    return matchesRarity && matchesSearch;
  });

  return (
    <div className="max-w-6xl mx-auto py-8 px-4">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 mb-8">
        <div>
          <h1 className="text-3xl font-display font-bold text-gray-800">My Inventory</h1>
          <p className="text-muted-foreground">Manage your collected characters</p>
        </div>

          <div className="flex flex-wrap items-center gap-4 w-full md:w-auto">
            {/* Coin Exchange Section */}
            {wallet && wallet.coins >= 0 && (
              <div className="flex items-center gap-3 bg-white p-2 pl-4 pr-2 rounded-2xl border border-border shadow-sm">
                <div className="flex items-center gap-2">
                  <Coins className="w-5 h-5 text-amber-500 fill-amber-500" />
                  <span className="font-bold text-amber-700">{wallet.coins}</span>
                </div>
                <div className="w-px h-6 bg-gray-200" />
                <Button 
                  size="sm" 
                  variant="ghost" 
                  className="rounded-xl gap-2 font-bold hover:bg-amber-50 text-amber-600 h-9"
                  onClick={handleTrade}
                  disabled={isTrading || wallet.coins < 100}
                >
                  <RefreshCw className={`w-4 h-4 ${isTrading ? 'animate-spin' : ''}`} />
                  Trade 100
                </Button>
              </div>
            )}

            {/* Search */}
            <div className="relative flex-1 md:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search name..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-white border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
              />
            </div>

            {/* Filter Pills */}
            <div className="flex gap-2">
              {[4, 3, 2, 1].map((stars) => (
                <button
                  key={stars}
                  onClick={() => setFilterRarity(filterRarity === stars ? null : stars)}
                  className={`
                    px-4 py-2 rounded-xl text-sm font-bold transition-all border
                    ${filterRarity === stars 
                      ? stars === 4 
                        ? 'bg-orange-600 text-white border-orange-400 shadow-lg shadow-orange-200'
                        : 'bg-primary text-white border-primary shadow-lg shadow-primary/20' 
                      : 'bg-white text-gray-600 border-border hover:bg-gray-50'}
                  `}
                >
                  {stars}★
                </button>
              ))}
            </div>
          </div>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6">
            {[...Array(10)].map((_, i) => (
              <div key={i} className="aspect-[3/4] bg-gray-100 rounded-2xl animate-pulse" />
            ))}
          </div>
        ) : filteredInventory && filteredInventory.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6">
            {filteredInventory.map((character) => (
              <CharacterCard key={character.id} character={character} />
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-white rounded-3xl border border-dashed border-border">
            <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Filter className="w-8 h-8 text-gray-300" />
            </div>
            <h3 className="text-xl font-bold text-gray-800 mb-2">No characters found</h3>
            <p className="text-muted-foreground">Try adjusting your filters or pull more gacha!</p>
          </div>
        )}
    </div>
  );
}
