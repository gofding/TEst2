import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Home from "@/pages/Home";
import Inventory from "@/pages/Inventory";
import Showcase from "@/pages/Showcase";
import NotFound from "@/pages/not-found";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { useAuth } from "@/hooks/use-auth";
import { useWallet } from "@/hooks/use-gacha";
import { Carrot, LogOut, Gift, Play, Coins } from "lucide-react";
import { useState } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { CoinExchange } from "@/components/CoinExchange";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/inventory" component={Inventory} />
      <Route path="/showcase" component={Showcase} />
      <Route component={NotFound} />
    </Switch>
  );
}

function MainLayout() {
  const { user, logout } = useAuth();
  const { data: wallet } = useWallet();
  const [isClaiming, setIsClaiming] = useState(false);
  const { toast } = useToast();

  const setCarrots = async (amount: number) => {
    await apiRequest("POST", "/api/dev/carrots", { amount });
    queryClient.invalidateQueries({ queryKey: ["/api/user/wallet"] });
  };

  const claimDaily = async () => {
    setIsClaiming(true);
    try {
      await apiRequest("POST", "/api/user/rewards/daily");
      toast({ title: "Success!", description: "You claimed 3,000 daily carrots!" });
      queryClient.invalidateQueries({ queryKey: ["/api/user/wallet"] });
    } catch (e) {
      toast({ title: "Not yet!", description: "Daily reward already claimed today.", variant: "destructive" });
    } finally {
      setIsClaiming(false);
    }
  };

  const watchVideo = () => {
    window.open("https://youtu.be/ydd-Sz4iMjM", "_blank");
    setTimeout(async () => {
      await apiRequest("POST", "/api/user/rewards/video");
      toast({ title: "Reward earned!", description: "You got 500 carrots for watching!" });
      queryClient.invalidateQueries({ queryKey: ["/api/user/wallet"] });
    }, 2000);
  };

  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "4rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar />
        <div className="flex flex-col flex-1 overflow-hidden">
          <header className="sticky top-0 z-40 w-full backdrop-blur-lg bg-secondary border-b border-border/40 shadow-sm">
            <div className="px-2 sm:px-4 h-14 sm:h-16 flex items-center justify-between">
              <div className="flex items-center gap-1 sm:gap-2">
                <SidebarTrigger data-testid="button-sidebar-toggle" />
                <h1 className="font-bold text-base sm:text-lg truncate max-w-[120px] sm:max-w-none text-secondary-foreground">Umamusume Gacha</h1>
              </div>

              {user && (
                <div className="flex items-center gap-1.5 sm:gap-4">
                  {/* Rewards - Hidden on mobile, accessible via sidebar or separate menu if needed */}
                  <div className="hidden lg:flex items-center gap-2">
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="rounded-full gap-2 bg-white/50 border-secondary-foreground/20 text-secondary-foreground"
                      onClick={claimDaily}
                      disabled={isClaiming}
                    >
                      <Gift className="w-4 h-4" />
                      <span>Daily</span>
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="rounded-full gap-2 bg-white/50 border-secondary-foreground/20 text-secondary-foreground"
                      onClick={watchVideo}
                    >
                      <Play className="w-4 h-4 fill-current" />
                      <span>Bonus</span>
                    </Button>
                    <CoinExchange />
                  </div>

                  {/* Wallet */}
                  <div className="flex items-center gap-1 sm:gap-2">
                    <div className="flex items-center gap-1 bg-amber-50 px-1.5 sm:px-3 py-0.5 sm:py-1 rounded-full border border-amber-200">
                      <Coins className="w-3 h-3 text-amber-500 fill-amber-500" />
                      <span className="text-[10px] sm:text-sm font-bold text-amber-700">{wallet && 'coins' in wallet ? (wallet as any).coins.toLocaleString() : "0"}</span>
                    </div>
                    <div 
                      className="flex items-center gap-1 bg-yellow-50 px-1.5 sm:px-3 py-0.5 sm:py-1 rounded-full border border-yellow-200 cursor-pointer active:scale-95 transition-transform"
                      onClick={() => setCarrots((wallet?.carrots || 0) + 1500)}
                    >
                      <Carrot className="w-3 h-3 text-orange-500 fill-orange-500" />
                      <span className="text-[10px] sm:text-sm font-bold text-orange-700">{wallet?.carrots?.toLocaleString() ?? "..."}</span>
                    </div>
                  </div>

                  {/* User Menu */}
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="rounded-full w-8 h-8 sm:w-10 sm:h-10 border bg-white overflow-hidden">
                        <img 
                          src={user.profileImageUrl || `https://api.dicebear.com/7.x/adventurer/svg?seed=${user.id}`}
                          alt="User"
                          className="w-full h-full object-cover"
                        />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-48">
                      <DropdownMenuItem className="lg:hidden" onClick={claimDaily} disabled={isClaiming}>
                        <Gift className="w-4 h-4 mr-2" />
                        Daily Reward
                      </DropdownMenuItem>
                      <DropdownMenuItem className="lg:hidden" onClick={watchVideo}>
                        <Play className="w-4 h-4 mr-2" />
                        Bonus Reward
                      </DropdownMenuItem>
                      <DropdownMenuItem className="text-red-600" onClick={() => logout()}>
                        <LogOut className="w-4 h-4 mr-2" />
                        Log out
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              )}
            </div>
          </header>
          <main className="flex-1 overflow-auto bg-gray-50/30">
            <Router />
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <MainLayout />
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
