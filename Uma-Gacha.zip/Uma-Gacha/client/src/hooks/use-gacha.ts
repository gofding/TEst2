import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { useAuth } from "./use-auth";

// GET /api/user/wallet
export function useWallet() {
  const { isAuthenticated } = useAuth();
  return useQuery({
    queryKey: [api.user.wallet.path],
    queryFn: async () => {
      const res = await fetch(api.user.wallet.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch wallet");
      const data = await res.json();
      return data as { carrots: number; coins: number };
    },
    enabled: isAuthenticated,
  });
}

// GET /api/user/inventory
export function useInventory() {
  const { isAuthenticated } = useAuth();
  return useQuery({
    queryKey: [api.user.inventory.path],
    queryFn: async () => {
      const res = await fetch(api.user.inventory.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch inventory");
      return api.user.inventory.responses[200].parse(await res.json());
    },
    enabled: isAuthenticated,
  });
}

// POST /api/gacha/pull
export function usePullGacha() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (amount: 1 | 10) => {
      const res = await fetch(api.gacha.pull.path, {
        method: api.gacha.pull.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount }),
        credentials: "include",
      });
      
      if (!res.ok) {
        if (res.status === 400) {
           const error = api.gacha.pull.responses[400].parse(await res.json());
           throw new Error(error.message);
        }
        throw new Error("Failed to pull gacha");
      }
      return api.gacha.pull.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      // Invalidate both wallet (balance changed) and inventory (new items)
      queryClient.invalidateQueries({ queryKey: [api.user.wallet.path] });
      queryClient.invalidateQueries({ queryKey: [api.user.inventory.path] });
    },
  });
}
