import { useCallback, useRef } from "react";

export function useButtonSound(soundPath: string) {
  const pool = useRef([
    new Audio(soundPath),
    new Audio(soundPath),
    new Audio(soundPath),
  ]);
  let index = 0;

  const play = useCallback(() => {
    const audio = pool.current[index];
    index = (index + 1) % pool.current.length;
    audio.currentTime = 0;
    audio.volume = 0.9;
    audio.play().catch(() => {});
  }, []);

  return play;
}