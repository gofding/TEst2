import { useState } from "react";
import { Coins, Carrot, ArrowRight, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useWallet } from "@/hooks/use-gacha";

export function CoinExchange() {
  const [amount, setAmount] = useState<string>("1000");
  const [isTrading, setIsTrading] = useState(false);
  const { data: wallet } = useWallet();
  const { toast } = useToast();

  const handleTrade = async () => {
    const numAmount = parseInt(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      toast({ title: "Invalid amount", variant: "destructive" });
      return;
    }

    if (!wallet || wallet.coins < numAmount) {
      toast({ title: "Insufficient coins", variant: "destructive" });
      return;
    }

    setIsTrading(true);
    try {
      await apiRequest("POST", "/api/user/trade-coins", { amount: numAmount });
      toast({ title: "Trade successful!", description: `Exchanged ${numAmount} coins for carrots!` });
      queryClient.invalidateQueries({ queryKey: ["/api/user/wallet"] });
      setAmount("1000");
    } catch (e) {
      toast({ title: "Trade failed", description: "An error occurred during the trade.", variant: "destructive" });
    } finally {
      setIsTrading(false);
    }
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button size="sm" variant="outline" className="rounded-full gap-2 border-amber-200 hover:bg-amber-50">
          <Coins className="w-4 h-4 text-amber-500 fill-amber-500" />
          <span>Exchange</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Coin Exchange</DialogTitle>
          <DialogDescription>
            Trade your duplicate character coins for carrots. 
            Exchange rate: 100 Coins = 100 Carrots.
          </DialogDescription>
        </DialogHeader>
        <div className="flex flex-col gap-4 py-4">
          <div className="flex items-center justify-between p-4 bg-secondary/50 rounded-lg">
            <div className="flex flex-col items-center gap-1">
              <span className="text-xs text-muted-foreground uppercase font-bold">You Have</span>
              <div className="flex items-center gap-1">
                <Coins className="w-5 h-5 text-amber-500 fill-amber-500" />
                <span className="text-xl font-bold">{wallet?.coins?.toLocaleString() ?? "0"}</span>
              </div>
            </div>
            <ArrowRight className="w-6 h-6 text-muted-foreground" />
            <div className="flex flex-col items-center gap-1">
              <span className="text-xs text-muted-foreground uppercase font-bold">You'll Get</span>
              <div className="flex items-center gap-1">
                <Carrot className="w-5 h-5 text-orange-500 fill-orange-500" />
                <span className="text-xl font-bold">{parseInt(amount) || 0}</span>
              </div>
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Amount to exchange</label>
            <div className="flex gap-2">
              <Input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="Enter coin amount..."
                min="1"
              />
              <Button variant="outline" onClick={() => setAmount(String(wallet?.coins || 0))}>Max</Button>
            </div>
          </div>
          <Button 
            className="w-full" 
            onClick={handleTrade} 
            disabled={isTrading || !amount || parseInt(amount) <= 0}
          >
            {isTrading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
            Confirm Exchange
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
