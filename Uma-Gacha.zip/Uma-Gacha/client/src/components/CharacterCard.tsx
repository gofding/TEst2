import type { Character } from "@shared/schema";
import { Star, Clock } from "lucide-react";

interface CharacterCardProps {
  character: Character & { obtainedAt?: string | null; count?: number };
}

export function CharacterCard({ character }: CharacterCardProps) {
  const isSSR = character.rarity === 3;
  const isUR = character.rarity === 4;
  
  return (
    <div className={`
      group relative overflow-visible rounded-2xl bg-white
      border-2 transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl
      aspect-[2/3] w-full
      ${isUR 
        ? 'border-transparent shadow-none' 
        : isSSR 
          ? 'border-yellow-400/50 shadow-yellow-100 shadow-lg' 
          : 'border-border shadow-sm hover:border-primary/30'}
    `}>
      {/* Rarity Glow Effects */}
      {isUR && <div className="rarity-4-glow" />}
      {isSSR && <div className="rarity-3-glow" />}

      <div className={`
        relative overflow-hidden rounded-2xl h-full flex flex-col
        ${isUR ? 'ur-card-frame' : isSSR ? 'ssr-card-frame' : ''}
      `}>
        {/* Image Container - Full Card Body for Poster Look */}
        <div className="flex-1 overflow-hidden bg-gray-50 relative">
          <img 
            src={character.imageUrl} 
            alt={character.name}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            loading="lazy"
          />
          
          {/* Overlay for Info - Modern Poster Style */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-80 group-hover:opacity-100 transition-opacity duration-300" />
          
          {/* Count Badge (if > 1) */}
          {character.count && character.count > 1 && (
            <div className="absolute top-3 right-3 bg-primary text-white text-xs font-extrabold px-2.5 py-1 rounded-full shadow-lg z-10 scale-110">
              x{character.count}
            </div>
          )}

          {/* Info Section - Absolute Positioned on Image */}
          <div className="absolute bottom-0 left-0 right-0 p-4 pb-6">
            {/* Rarity Stars */}
            <div className={`
              flex gap-0.5 mb-2 px-2 py-1 w-fit rounded-full shadow-sm backdrop-blur-md border
              ${isUR ? 'bg-orange-600/80 border-orange-400/50' : 'bg-white/80 border-white/20'}
            `}>
              {Array.from({ length: character.rarity }).map((_, i) => (
                <Star key={i} className={`w-3.5 h-3.5 ${isUR ? 'fill-yellow-300 text-yellow-300' : isSSR ? 'fill-yellow-400 text-yellow-400' : 'fill-gray-400 text-gray-400'}`} />
              ))}
            </div>

            <h3 className="font-display font-extrabold text-xl lg:text-2xl leading-tight text-white drop-shadow-md">
              {character.name}
            </h3>
            
            <p className="text-white/80 text-xs mt-1 line-clamp-2 italic drop-shadow-sm font-medium">
              {character.description}
            </p>
            
            {character.obtainedAt && (
              <div className="flex items-center gap-1 mt-3 text-[10px] uppercase tracking-wider text-white/60 font-bold">
                <Clock className="w-3 h-3" />
                <span>Acquired {new Date(character.obtainedAt).toLocaleDateString()}</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
