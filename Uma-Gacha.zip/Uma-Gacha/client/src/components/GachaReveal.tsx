import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect } from "react";
import type { Character } from "@shared/schema";
import { Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useButtonSound } from "@/hooks/useButtonSound"; // ✅ add this import

interface GachaRevealProps {
  results: Character[];
  isOpen: boolean;
  onClose: () => void;
  onRedo?: () => void;
}

export function GachaReveal({ results, isOpen, onClose, onRedo }: GachaRevealProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showSummary, setShowSummary] = useState(false);
  const [isFlashing, setIsFlashing] = useState(false);

  // ✅ Add sounds for reveal, high rarity, and summary
  const playCardReveal = useButtonSound(
    "https://raw.githubusercontent.com/gofding/TEst2/main/umamusume_sfx_02.mp3"
  );
  const playRareReveal = useButtonSound(
    "https://raw.githubusercontent.com/gofding/TEst2/main/umamusume_sfx_03.mp3"
  );
  const playSummary = useButtonSound(
    "https://raw.githubusercontent.com/gofding/TEst2/main/umamusume_sfx_01.mp3"
  );

  useEffect(() => {
    if (isOpen) {
      setCurrentIndex(0);
      setShowSummary(false);
      triggerFlash(results[0]?.rarity);
    }
  }, [isOpen]);

  const triggerFlash = (rarity: number) => {
    if (rarity >= 3) {
      setIsFlashing(true);
      setTimeout(() => setIsFlashing(false), 1200);
    }
  };

  const handleNext = () => {
    if (currentIndex < results.length - 1) {
      const nextRarity = results[currentIndex + 1].rarity;
      setCurrentIndex(prev => prev + 1);
      triggerFlash(nextRarity);

      // ✅ Play reveal sounds
      if (nextRarity >= 4) playRareReveal();
      else playCardReveal();
    } else {
      setShowSummary(true);
      playSummary(); // ✅ summary open sound
    }
  };

  const currentCharacter = results[currentIndex];
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#f0fdf4] overflow-hidden">
        {/* Flash Effect */}
        {isFlashing && (
          <div
            className={`absolute inset-0 z-[60] pointer-events-none ${
              results[currentIndex].rarity === 4 ? "flash-4-stars" : "flash-3-stars"
            }`}
          />
        )}

        {/* Background */}
        <div className="absolute inset-0 z-0 opacity-20 pointer-events-none">
          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/diagonal-stripes.png')] repeat" />
        </div>

        {/* Header */}
        <div className="relative z-10 w-full max-w-2xl px-4 mb-8">
          <div className="bg-white rounded-r-full rounded-l-lg py-3 px-12 shadow-sm border-l-8 border-l-primary transform -skew-x-12 ml-4">
            <h2 className="text-2xl font-black text-slate-700 tracking-tighter skew-x-12 italic uppercase">
              Scout Results
            </h2>
          </div>
        </div>

        {/* Character Reveal */}
        {!showSummary && currentCharacter && (
          <motion.div
            key={currentIndex}
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 1.2, opacity: 0 }}
            transition={{ duration: 0.4 }}
            className="relative z-10 w-full max-w-lg cursor-pointer px-4"
            onClick={handleNext}
          >
            <div
              className={`relative bg-white p-6 rounded-[2.5rem] border-4 shadow-2xl transition-colors duration-500 ${
                currentCharacter.rarity === 4
                  ? "border-orange-500 animate-ur-glow"
                  : currentCharacter.rarity === 3
                  ? "border-yellow-400 animate-ssr-glow"
                  : "border-slate-100"
              }`}
            >
              <div className="aspect-square rounded-[2rem] overflow-hidden mb-6 bg-slate-50 border-2 border-slate-100">
                <img
                  src={currentCharacter.imageUrl}
                  alt={currentCharacter.name}
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="text-center space-y-2">
                <h3 className="text-3xl font-black text-slate-800 tracking-tight">
                  {currentCharacter.name}
                </h3>
                <div className="flex justify-center gap-1">
                  {Array.from({ length: currentCharacter.rarity }).map((_, i) => (
                    <Star
                      key={i}
                      className="w-8 h-8 fill-yellow-400 text-yellow-400 drop-shadow-[0_2px_4px_rgba(0,0,0,0.2)]"
                    />
                  ))}
                </div>
                <p className="text-slate-400 font-bold uppercase tracking-widest text-xs pt-4 animate-pulse">
                  Tap to continue
                </p>
              </div>
            </div>
          </motion.div>
        )}

        {/* Summary Grid */}
        {showSummary && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="fixed inset-0 z-[70] bg-[#f0fdf4] flex flex-col items-center h-full overflow-y-auto pt-20 pb-12"
          >
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-x-4 gap-y-10 w-full max-w-4xl px-4 justify-items-center mb-12 sm:mb-16">
              {results.map((char, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  className="relative group"
                >
                  <div
                    className={`relative w-28 h-28 sm:w-32 sm:h-32 rounded-3xl border-4 overflow-hidden bg-white shadow-md ${
                      char.rarity === 4
                        ? "border-orange-500 animate-ur-glow ring-4 ring-orange-500/20"
                        : char.rarity === 3
                        ? "border-yellow-400 animate-ssr-glow ring-4 ring-yellow-400/20"
                        : "border-slate-200"
                    }`}
                  >
                    <img src={char.imageUrl} alt={char.name} className="w-full h-full object-cover" />
                    <div className="absolute top-0 left-0 bg-red-500 text-white text-[10px] font-black px-2 py-0.5 italic rounded-br-lg shadow-sm">
                      NEW!
                    </div>
                  </div>

                  <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 flex gap-0.5 bg-white/90 backdrop-blur-sm px-2 py-0.5 rounded-full shadow-sm border border-slate-100">
                    {Array.from({ length: char.rarity }).map((_, i) => (
                      <Star key={i} className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Buttons */}
            <div className="w-full max-w-md flex flex-col sm:flex-row gap-3 sm:gap-4 mt-auto px-6">
              <Button
                variant="outline"
                size="lg"
                onClick={onClose}
                className="flex-1 rounded-2xl h-12 sm:h-14 text-lg sm:text-xl font-black text-slate-600 border-4 border-slate-200 hover:bg-slate-50 transition-all shadow-lg order-2 sm:order-1"
              >
                Back
              </Button>
              <Button
                size="lg"
                onClick={() => {
                  if (onRedo) {
                    onClose();
                    setTimeout(onRedo, 100);
                  }
                }}
                className="flex-1 rounded-2xl h-12 sm:h-14 text-lg sm:text-xl font-black bg-primary hover:bg-primary/90 text-white border-4 border-primary shadow-lg shadow-primary/20 order-1 sm:order-2"
              >
                Scout Again
              </Button>
            </div>

            <p className="mt-6 sm:mt-8 text-slate-500 font-bold text-xs text-center max-w-sm px-6">
              Trainees you've already scouted grant Goddess Statues instead.
            </p>
          </motion.div>
        )}
      </div>
    </AnimatePresence>
  );
}
