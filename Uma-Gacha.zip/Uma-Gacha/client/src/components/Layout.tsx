import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useWallet } from "@/hooks/use-gacha";
import { Carrot, User, LogOut, LayoutGrid, Home, Settings, Gift, Play, Coins } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function Layout({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  const { data: wallet } = useWallet();
  const [location] = useLocation();
  const [isClaiming, setIsClaiming] = useState(false);
  const { toast } = useToast();

  const setCarrots = async (amount: number) => {
    await apiRequest("POST", "/api/dev/carrots", { amount });
    queryClient.invalidateQueries({ queryKey: ["/api/user/wallet"] });
  };

  const claimDaily = async () => {
    setIsClaiming(true);
    try {
      await apiRequest("POST", "/api/user/rewards/daily");
      toast({ title: "Success!", description: "You claimed 3,000 daily carrots!" });
      queryClient.invalidateQueries({ queryKey: ["/api/user/wallet"] });
    } catch (e) {
      toast({ title: "Not yet!", description: "Daily reward already claimed today.", variant: "destructive" });
    } finally {
      setIsClaiming(false);
    }
  };

  const watchVideo = () => {
    window.open("https://youtu.be/ydd-Sz4iMjM", "_blank");
    setTimeout(async () => {
      await apiRequest("POST", "/api/user/rewards/video");
      toast({ title: "Reward earned!", description: "You got 500 carrots for watching!" });
      queryClient.invalidateQueries({ queryKey: ["/api/user/wallet"] });
    }, 2000);
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Navigation */}
      <header className="sticky top-0 z-40 w-full backdrop-blur-lg bg-white/80 border-b border-border/40 shadow-sm">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
             <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center transform group-hover:rotate-12 transition-transform">
               <Carrot className="text-white w-5 h-5" />
             </div>
             <span className="font-display font-bold text-xl tracking-tight text-primary">
               Derby<span className="text-secondary-foreground">Gacha</span>
             </span>
          </Link>

          {/* Desktop Nav */}
          {user ? (
            <div className="flex items-center gap-4">
              <nav className="flex items-center gap-1">
                <Link href="/">
                  <Button variant={location === "/" ? "secondary" : "ghost"} className="gap-2 rounded-full px-3 sm:px-4">
                    <Home className="w-4 h-4" />
                    <span className="hidden sm:inline">Summon</span>
                  </Button>
                </Link>
                <Link href="/inventory">
                  <Button variant={location === "/inventory" ? "secondary" : "ghost"} className="gap-2 rounded-full px-3 sm:px-4">
                    <LayoutGrid className="w-4 h-4" />
                    <span className="hidden sm:inline">Inventory</span>
                  </Button>
                </Link>
              </nav>

              {/* Rewards */}
              <div className="flex items-center gap-2">
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="rounded-full gap-2 border-primary/20 hover:bg-primary/5 text-primary"
                  onClick={claimDaily}
                  disabled={isClaiming}
                >
                  <Gift className="w-4 h-4" />
                  <span className="hidden sm:inline">Daily</span>
                </Button>
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="rounded-full gap-2 border-secondary/40 hover:bg-secondary/5 text-secondary-foreground"
                  onClick={watchVideo}
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span className="hidden sm:inline">Bonus</span>
                </Button>
              </div>

              {/* Wallet Display - Click icon to add 1500 carrots */}
              <div className="hidden lg:flex items-center gap-2">
                {/* Coin Display */}
                <div className="flex items-center gap-2 bg-amber-50 px-3 py-1.5 rounded-full border border-amber-200 shadow-sm group relative">
                  <Coins className="w-4 h-4 text-amber-500 fill-amber-500" />
                  <span className="font-mono font-bold text-amber-700 select-none">{wallet?.coins.toLocaleString() ?? "0"}</span>
                  {/* Tooltip or small trade button could go here, but we'll add it to a shop or dedicated UI later */}
                </div>

                <div 
                  className="flex items-center gap-2 bg-yellow-50 px-4 py-1.5 rounded-full border border-yellow-200"
                >
                  <div 
                    className="cursor-pointer active:scale-125 transition-transform hover:rotate-12 p-1 -m-1"
                    onClick={async (e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      await setCarrots((wallet?.carrots || 0) + 1500);
                    }}
                  >
                    <Carrot className="w-5 h-5 text-orange-500 fill-orange-500" />
                  </div>
                  <span className="font-mono font-bold text-orange-700 select-none">{wallet?.carrots.toLocaleString() ?? "..."}</span>
                </div>
              </div>

              {/* User Menu */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="rounded-full w-10 h-10 border border-border bg-white">
                    <img 
                      src={user.profileImageUrl || `https://api.dicebear.com/7.x/adventurer/svg?seed=${user.id}`}
                      alt={user.firstName || "User"}
                      className="w-full h-full rounded-full object-cover"
                    />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56 rounded-xl p-2">
                  <div className="px-2 py-1.5 text-sm font-semibold text-muted-foreground">
                    Hey, {user.firstName || "Trainer"}
                  </div>
                  <DropdownMenuItem className="rounded-lg cursor-pointer text-red-600 focus:text-red-600" onClick={() => logout()}>
                    <LogOut className="w-4 h-4 mr-2" />
                    Log out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          ) : (
            <Link href="/api/login">
              <Button className="rounded-full px-6 font-bold bg-primary hover:bg-primary/90 text-white shadow-lg shadow-primary/25">
                Login with Replit
              </Button>
            </Link>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-8">
        {children}
      </main>

      {/* Footer */}
      <footer className="border-t border-border/40 py-8 bg-white/50 mt-auto">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>© 2024 DerbyGacha. Not affiliated with Cygames.</p>
          <p className="mt-2 text-xs">Fan made simulator project.</p>
        </div>
      </footer>
    </div>
  );
}
