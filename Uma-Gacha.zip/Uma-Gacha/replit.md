# DerbyGacha - Uma Musume Gacha Game

## Overview

DerbyGacha is a gacha-style character collection game themed around Uma Musume (horse girl racing anime). Users can spend in-game currency (carrots) to summon random characters of varying rarities, build their collection, and view their inventory. The application features animated gacha reveals, a clean mobile-responsive UI, and Replit authentication integration.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **UI Components**: shadcn/ui component library (Radix primitives)
- **Animations**: Framer Motion for gacha reveal effects
- **Build Tool**: Vite with path aliases (@/, @shared/, @assets/)

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript with ESM modules
- **API Style**: RESTful JSON endpoints under /api/*
- **Build**: esbuild for production bundling with selective dependency bundling

### Data Storage
- **Database**: PostgreSQL
- **ORM**: Drizzle ORM with Zod schema validation (drizzle-zod)
- **Schema Location**: `shared/schema.ts` for shared types between client/server
- **Migrations**: Drizzle Kit with `db:push` command

### Authentication
- **Method**: Replit OpenID Connect (OIDC) authentication
- **Session Storage**: PostgreSQL-backed sessions via connect-pg-simple
- **User Management**: Automatic upsert on login with profile sync
- **Protected Routes**: `isAuthenticated` middleware for API endpoints

### Key Data Models
- **users**: Replit auth user profiles (id, email, name, avatar)
- **sessions**: Express session storage for auth
- **characters**: Gacha pool characters with name, rarity (1-3), image, description
- **wallets**: User currency balance (carrots)
- **userCharacters**: Junction table tracking obtained characters with timestamps

### Gacha System
- Pull costs: 150 carrots (single), 1500 carrots (10-pull)
- Rarity distribution: 1-star (common), 2-star (uncommon), 3-star (rare/SSR)
- Starting balance: 15,000 carrots per user

## External Dependencies

### Database
- PostgreSQL database (required, connection via DATABASE_URL environment variable)

### Authentication
- Replit OIDC provider (ISSUER_URL defaults to https://replit.com/oidc)
- Requires REPL_ID and SESSION_SECRET environment variables

### Third-Party Libraries
- **@radix-ui/***: Accessible UI primitive components
- **framer-motion**: Animation library for gacha reveals
- **passport**: Authentication middleware with openid-client strategy
- **drizzle-orm + drizzle-kit**: Database ORM and migration tools
- **lucide-react**: Icon library

### Replit-Specific Integrations
- @replit/vite-plugin-runtime-error-modal: Development error overlay
- @replit/vite-plugin-cartographer: Development tooling
- @replit/vite-plugin-dev-banner: Development environment indicator