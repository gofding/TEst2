import { users, characters, wallets, userCharacters, type User, type Character, type Wallet, type UserCharacter } from "@shared/schema";
import { db } from "./db";
import { eq, sql } from "drizzle-orm";
import { authStorage } from "./replit_integrations/auth/storage";

export interface IStorage {
  // User & Auth (delegated to authStorage where possible or extended)
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: any): Promise<User>;

  // Wallet
  getWallet(userId: string): Promise<Wallet | undefined>;
  createWallet(userId: string): Promise<Wallet>;
  updateWallet(userId: string, carrots: number, coins?: number): Promise<Wallet>;
  setCarrots(userId: string, carrots: number): Promise<Wallet>;
  claimDailyReward(userId: string): Promise<Wallet | null>;
  tradeCoins(userId: string, coinAmount: number): Promise<Wallet | null>;
  // Characters
  getCharacters(): Promise<Character[]>;
  getCharacter(id: number): Promise<Character | undefined>;
  createCharacter(character: Omit<Character, "id">): Promise<Character>;

  // User Characters
  getUserCharacters(userId: string): Promise<(Character & { obtainedAt: Date | null; count: number })[]>;
  addToUserCollection(userId: string, characterId: number): Promise<UserCharacter>;
}

export class DatabaseStorage implements IStorage {
  // Auth delegation
  async getUser(id: string): Promise<User | undefined> {
    return authStorage.getUser(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return undefined;
  }

  async createUser(insertUser: any): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Wallet
  async getWallet(userId: string): Promise<Wallet | undefined> {
    const [wallet] = await db.select().from(wallets).where(eq(wallets.userId, userId));
    return wallet;
  }

  async createWallet(userId: string): Promise<Wallet> {
    const [wallet] = await db.insert(wallets).values({ userId, carrots: 15000 }).returning();
    return wallet;
  }

  async updateWallet(userId: string, carrots: number, coins?: number): Promise<Wallet> {
    const updateData: any = { carrots };
    if (coins !== undefined) updateData.coins = coins;
    
    const [wallet] = await db
      .update(wallets)
      .set(updateData)
      .where(eq(wallets.userId, userId))
      .returning();
    return wallet;
  }

  async setCarrots(userId: string, carrots: number): Promise<Wallet> {
    const [wallet] = await db
      .update(wallets)
      .set({ carrots })
      .where(eq(wallets.userId, userId))
      .returning();
    return wallet;
  }

  async tradeCoins(userId: string, coinAmount: number): Promise<Wallet | null> {
    const [wallet] = await db.select().from(wallets).where(eq(wallets.userId, userId));
    if (!wallet || wallet.coins < coinAmount) return null;

    const carrotsToAdd = coinAmount; // 100 coins = 100 carrots (1:1 rate)
    
    const [updated] = await db
      .update(wallets)
      .set({ 
        coins: wallet.coins - coinAmount,
        carrots: wallet.carrots + carrotsToAdd
      })
      .where(eq(wallets.userId, userId))
      .returning();
    return updated;
  }

  async claimDailyReward(userId: string): Promise<Wallet | null> {
    const [wallet] = await db.select().from(wallets).where(eq(wallets.userId, userId));
    if (!wallet) return null;

    const now = new Date();
    const lastClaim = wallet.lastDailyReward;
    
    // Check if 24 hours have passed
    if (lastClaim && now.getTime() - lastClaim.getTime() < 24 * 60 * 60 * 1000) {
      return null;
    }

    const [updated] = await db
      .update(wallets)
      .set({ 
        carrots: wallet.carrots + 3000, 
        lastDailyReward: now 
      })
      .where(eq(wallets.userId, userId))
      .returning();
    return updated;
  }

  // Characters
  async getCharacters(): Promise<Character[]> {
    return await db.select().from(characters);
  }

  async getCharacter(id: number): Promise<Character | undefined> {
    const [character] = await db.select().from(characters).where(eq(characters.id, id));
    return character;
  }

  async createCharacter(character: Omit<Character, "id">): Promise<Character> {
    const [newChar] = await db.insert(characters).values(character).returning();
    return newChar;
  }

  // User Characters
  async getUserCharacters(userId: string): Promise<(Character & { obtainedAt: Date | null; count: number })[]> {
    const rows = await db
      .select({
        character: characters,
        obtainedAt: sql<Date>`max(${userCharacters.obtainedAt})`,
        count: sql<number>`count(${userCharacters.id})`
      })
      .from(userCharacters)
      .innerJoin(characters, eq(userCharacters.characterId, characters.id))
      .where(eq(userCharacters.userId, userId))
      .groupBy(characters.id);

    return rows.map(row => ({
      ...row.character,
      obtainedAt: row.obtainedAt,
      count: Number(row.count)
    }));
  }

  async addToUserCollection(userId: string, characterId: number): Promise<UserCharacter> {
    const [entry] = await db.insert(userCharacters).values({ userId, characterId }).returning();
    return entry;
  }
}

export const storage = new DatabaseStorage();
