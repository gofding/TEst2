import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { setupAuth, registerAuthRoutes } from "./replit_integrations/auth";
import { isAuthenticated } from "./replit_integrations/auth/replitAuth";

const PULL_COST = 150;

const INITIAL_CHARACTERS = [
  // 1-STAR
  { name: "Twin Turbo", rarity: 1, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/c/c1/Twin_Turbo_Icon.png", description: "The ultimate escape artist." },
  { name: "Mejiro Ryan", rarity: 1, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/8/8a/Mejiro_Ryan_Icon.png", description: "The sporty Mejiro." },
  { name: "Agnes Tachyon", rarity: 1, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/3/39/Agnes_Tachyon_%28Main%29.png", description: "Mad scientist." },
  { name: "Winning Ticket", rarity: 1, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/d/d1/Winning_Ticket_Icon.png", description: "Passion for victory." },
  { name: "Sakura Bakushin O", rarity: 1, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/9/96/Sakura_Bakushin_O_%28Main%29.png", description: "Speed is everything!" },
  { name: "Haru Urara", rarity: 1, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/2/25/Haru_Urara_%28Main%29.png", description: "Never give up!" },
  { name: "Matikanefukukitaru", rarity: 1, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/b/b3/Matikanefukukitaru_Icon.png", description: "Lucky runner." },
  { name: "Nice Nature", rarity: 1, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/1/15/Nice_Nature_Icon.png", description: "Perpetual third place." },
  { name: "King Halo", rarity: 1, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/0/07/King_Halo_Icon.png", description: "The elite runner." },

  // 2-STAR
  { name: "Tsurumaru Tsuyoshi", rarity: 2, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/d/dc/Tsurumaru_Tsuyoshi_Icon.png", description: "Strong and persistent." },
  { name: "Ikuno Dictus", rarity: 2, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/a/a2/Ikuno_Dictus_Icon.png", description: "The reliable one." },
  { name: "Biko Pegasus", rarity: 2, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/a/a4/Biko_Pegasus_%28Main%29.png", description: "Tiny hero." },
  { name: "Matikanetannhauser", rarity: 2, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/2/2a/Matikanetannhauser_%28Main%29.png", description: "Cheerful Tannhauser." },
  { name: "Gold Ship", rarity: 2, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/8/8e/Gold_Ship_%28Main%29.png", description: "Unpredictable." },
  { name: "Vodka", rarity: 2, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/c/c0/Vodka_Icon.png", description: "The cool girl." },
  { name: "Daiwa Scarlet", rarity: 2, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/1/12/Daiwa_Scarlet_Icon.png", description: "Number one!" },
  { name: "Grass Wonder", rarity: 2, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/a/a9/Grass_Wonder_Icon.png", description: "The serene healer." },
  { name: "El Condor Pasa", rarity: 2, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/0/06/El_Condor_Pasa_Icon.png", description: "The Mexican luchador." },
  { name: "Air Groove", rarity: 2, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/7/7d/Air_Groove_%28Main%29.png", description: "The Empress." },
  { name: "Mayano Top Gun", rarity: 2, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/d/d4/Mayano_Top_Gun_Icon.png", description: "High-flying idol." },
  { name: "Super Creek", rarity: 2, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/2/29/Super_Creek_Icon.png", description: "Motherly care." },

  // 3-STAR
  { name: "Stay Gold", rarity: 3, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/4/44/Stay_Gold_%28Main%29.png", description: "Persistent legend." },
  { name: "Buena Vista", rarity: 3, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/7/7e/Buena_Vista_%28Main%29.png", description: "The queen of scenery." },
  { name: "Dantsu Flame", rarity: 3, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/2/26/Dantsu_Flame_Icon.png", description: "Energetic runner." },
  { name: "Believe", rarity: 3, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/3/38/Believe_%28Main%29.png", description: "Believe in victory." },
  { name: "Espoir City", rarity: 3, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/b/b3/Espoir_City_Icon.png", description: "The dirt legend." },
  { name: "Orfevre", rarity: 3, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/d/dc/Orfevre_%28Main%29.png", description: "Golden king." },
  { name: "Gentildonna", rarity: 3, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/b/b5/Gentildonna_Icon.png", description: "The lady legend." },
  { name: "Jungle Pocket", rarity: 3, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/c/c5/Jungle_Pocket_Icon.png", description: "Rock on!" },
  { name: "Vivlos", rarity: 3, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/b/be/Vivlos_Icon.png", description: "The little sister." },
  { name: "Duramente", rarity: 3, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/1/15/Duramente_Icon.png", description: "The dominant runner." },

  // SPECIAL TIER (4-STAR)
  { name: "Bubble Gum Fellow (New Year)", rarity: 4, imageUrl: "https://gametora.com/images/umamusume/characters/chara_stand_1124_112402.png", description: "Celebrating the New Year in style!" },
  { name: "Special Week (Commander)", rarity: 4, imageUrl: "/attached_assets/chara_stand_1001_100103_1768630298350.png", description: "Leading the charge with a fresh New Year spirit!" },
  { name: "Gold Ship (Summer)", rarity: 4, imageUrl: "https://gametora.com/images/umamusume/characters/chara_stand_1007_100702.png", description: "Summer chaos at its finest." },
  { name: "Oguri Cap (Christmas)", rarity: 4, imageUrl: "https://gametora.com/images/umamusume/characters/chara_stand_1006_100602.png", description: "Spreading holiday cheer with a massive appetite." },
  { name: "Kitasan Black (New Year)", rarity: 4, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/5/52/Kitasan_Black_Icon.png", description: "New year, new goals!" },
  { name: "Satono Diamond (New Year)", rarity: 4, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/f/ff/Satono_Diamond_Icon.png", description: "Radiant start to the year." },
  { name: "Mejiro McQueen (Summer)", rarity: 4, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/c/c3/Mejiro_McQueen_Icon.png", description: "Elegant summer vibes." },
  { name: "Rice Shower (Halloween)", rarity: 4, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/7/75/Rice_Shower_Icon.png", description: "Spooky but sweet." },
  { name: "Silence Suzuka (Summer)", rarity: 4, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/f/f6/Silence_Suzuka_Icon.png", description: "Racing through the summer heat." },
  { name: "Agnes Tachyon (Summer)", rarity: 4, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/3/39/Agnes_Tachyon_%28Main%29.png", description: "Summer experiment in progress." },
  { name: "Tokai Teio (Anime Collab)", rarity: 4, imageUrl: "https://static.wikia.nocookie.net/umamusume/images/6/67/Tokai_Teio_Icon.png", description: "The miracle runner." },
  { name: "Agnes Tachyon (Alt Version)", rarity: 4, imageUrl: "/attached_assets/Agnes_Tachyon_Alt_Version_1768630008017.jpg", description: "A brilliant and mysterious alternative style." },
  { name: "Manhattan Cafe (Valentine)", rarity: 4, imageUrl: "/attached_assets/Manhattan_Cafe_Valentine_1768630008017.png", description: "Sharing a quiet moment with a special treat." },
];

async function seedDatabase() {
  const existing = await storage.getCharacters();
  
  if (existing.length < INITIAL_CHARACTERS.length) {
    console.log("Updating character database with new tier list...");
    for (const char of INITIAL_CHARACTERS) {
      const exists = existing.find(e => e.name === char.name);
      if (!exists) {
        await storage.createCharacter(char);
      }
    }
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Auth setup
  await setupAuth(app);
  registerAuthRoutes(app);

  // Seed DB
  await seedDatabase();

  // Middleware to ensure wallet exists
  const ensureWallet = async (req: any, res: any, next: any) => {
    if (req.isAuthenticated()) {
      const userId = req.user.claims.sub;
      let wallet = await storage.getWallet(userId);
      if (!wallet) {
        wallet = await storage.createWallet(userId);
      }
    }
    next();
  };
  
  app.use(ensureWallet);

  // GET Wallet
  app.get(api.user.wallet.path, isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const wallet = await storage.getWallet(userId);
    res.json({ carrots: wallet ? wallet.carrots : 0, coins: wallet ? wallet.coins : 0 });
  });

  // GET Inventory
  app.get(api.user.inventory.path, isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const inventory = await storage.getUserCharacters(userId);
    // Transform dates to strings for JSON
    const serializedInventory = inventory.map(item => ({
      ...item,
      obtainedAt: (item.obtainedAt instanceof Date) ? item.obtainedAt.toISOString() : (item.obtainedAt || null)
    }));
    res.json(serializedInventory);
  });

  // POST Pull
  app.post(api.gacha.pull.path, isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const { amount } = api.gacha.pull.input.parse(req.body);
    const totalCost = amount * PULL_COST;

    const wallet = await storage.getWallet(userId);
    if (!wallet || wallet.carrots < totalCost) {
      return res.status(400).json({ message: "Insufficient carrots!" });
    }

    // Deduct cost
    await storage.updateWallet(userId, wallet.carrots - totalCost);

    const characters = await storage.getCharacters();
    const results = [];

    const existingCharacters = await storage.getUserCharacters(userId);
    const existingIds = new Set(existingCharacters.map(c => c.id));
    
    // Gacha Logic
    let coinsEarned = 0;
    for (let i = 0; i < amount; i++) {
      const rand = Math.random() * 100;
      let rarity = 1;
      if (rand < 0.1) rarity = 4;       // 0.1%
      else if (rand < 0.7) rarity = 3;  // 0.6% (0.1 + 0.6 = 0.7)
      else if (rand < 18.7) rarity = 2; // 18% (0.7 + 18 = 18.7)
      
      // Filter by rarity
      const pool = characters.filter(c => c.rarity === rarity);
      // Fallback if pool empty (shouldn't happen after seed)
      const finalPool = pool.length > 0 ? pool : characters;
      
      const pulledChar = finalPool[Math.floor(Math.random() * finalPool.length)];
      results.push(pulledChar);
      
      if (existingIds.has(pulledChar.id)) {
        // Award coins based on rarity
        // 1* -> 10, 2* -> 50, 3* -> 200, 4* -> 1000
        const coinRewards: Record<number, number> = { 1: 10, 2: 50, 3: 200, 4: 1000 };
        coinsEarned += coinRewards[pulledChar.rarity] || 10;
      }
      
      // Add to collection
      await storage.addToUserCollection(userId, pulledChar.id);
    }

    const newWallet = await storage.updateWallet(userId, (wallet.carrots - totalCost), (wallet.coins + coinsEarned));
    
    res.json({
      results,
      newBalance: newWallet ? newWallet.carrots : 0,
      newCoins: newWallet ? newWallet.coins : 0,
      coinsEarned
    });
  });

  // POST Trade Coins
  app.post("/api/user/trade-coins", isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const { amount } = z.object({ amount: z.number() }).parse(req.body);
    
    const wallet = await storage.tradeCoins(userId, amount);
    if (!wallet) {
      return res.status(400).json({ message: "Insufficient coins or wallet not found." });
    }
    res.json({ carrots: wallet.carrots, coins: wallet.coins });
  });

  // DEV: Set Carrots
  app.post("/api/dev/carrots", isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const { amount } = z.object({ amount: z.number() }).parse(req.body);
    const wallet = await storage.setCarrots(userId, amount);
    res.json({ carrots: wallet.carrots });
  });

  // Rewards: Claim Daily
  app.post("/api/user/rewards/daily", isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const wallet = await storage.claimDailyReward(userId);
    if (!wallet) {
      return res.status(400).json({ message: "Daily reward already claimed or wallet not found." });
    }
    res.json({ carrots: wallet.carrots });
  });

  // Rewards: Video
  app.post("/api/user/rewards/video", isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const wallet = await storage.getWallet(userId);
    if (!wallet) return res.status(404).json({ message: "Wallet not found" });
    
    const updated = await storage.updateWallet(userId, wallet.carrots + 500);
    res.json({ carrots: updated.carrots });
  });

  // GET All Characters
  app.get("/api/characters", isAuthenticated, async (req: any, res) => {
    const characters = await storage.getCharacters();
    res.json(characters);
  });

  return httpServer;
}
